export class Post{
    constructor(public name:string, public cost:Number){}
}